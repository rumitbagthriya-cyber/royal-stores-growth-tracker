# Royal Stores Growth Tracker — Capacitor + GitHub Actions

This zip contains the complete Capacitor project, pre-built and ready.
No Android Studio, no computer, no code to type or paste.

## What's inside
```
.github/workflows/build-apk.yml   <- the cloud build recipe
www/index.html                    <- your app, unchanged, all features intact
resources/                        <- app icon + splash screen source images
package.json
capacitor.config.json
.gitignore
```

## How to use this on your Android phone (2 uploads total)

GitHub can't automatically unzip a file into a repository's file tree, so
there's one small catch: GitHub Actions needs its workflow file to exist
as a real file at `.github/workflows/build-apk.yml` before anything can
run. Everything else — the app, the icons, the config — can travel inside
a single zip that the workflow unpacks for you automatically at build time.

So instead of creating six-plus files by hand, you only need to **upload
two things**, both by picking a file — never typing or pasting code:

1. **`build-apk.yml`** → uploaded to the exact path `.github/workflows/build-apk.yml`
2. **`project.zip`** → uploaded to the repo root (the workflow auto-extracts it during every build)

Full steps are in the chat message this file was shared in.
